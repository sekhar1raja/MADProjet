package com.example.group6_projectpart1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Details : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_candidate)
    }
}