package com.example.group6_projectpart1

class job (var Title:String = "",var name:String = "",var id:String = "",var image:String = "")